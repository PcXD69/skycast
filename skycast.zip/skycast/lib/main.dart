import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

Color wh(double o) => Color.fromRGBO(255, 255, 255, o);
Color bk(double o) => Color.fromRGBO(0, 0, 0, o);

const overlay = SystemUiOverlayStyle(
  statusBarColor: Colors.transparent,
  statusBarIconBrightness: Brightness.light,
  statusBarBrightness: Brightness.dark,
  systemNavigationBarColor: Colors.transparent,
  systemNavigationBarDividerColor: Colors.transparent,
  systemNavigationBarIconBrightness: Brightness.light,
  systemNavigationBarContrastEnforced: false,
);

const S = {
  'now': ['Now', 'اکنون'], 'today': ['Today', 'امروز'],
  'feels': ['Feels like', 'حس واقعی'], 'hum': ['Humidity', 'رطوبت'],
  'wind': ['Wind', 'باد'], 'pres': ['Pressure', 'فشار'], 'uv': ['UV index', 'شاخص UV'],
  'rain': ['Precipitation', 'بارش'], 'rise': ['Sunrise', 'طلوع'], 'set': ['Sunset', 'غروب'],
  'hr': ['Hourly', 'ساعتی'], 'dy': ['7 days', '۷ روز آینده'],
  'retry': ['Retry', 'تلاش دوباره'],
  'err': ['Couldn’t load weather. Check your connection.', 'دریافت اطلاعات ممکن نشد. اینترنت را بررسی کنید.'],
  'off': ['Offline · showing last update', 'آفلاین · آخرین اطلاعات ذخیره‌شده'],
  'me': ['My location', 'موقعیت من'], 'srch': ['Search city…', 'جستجوی شهر…'],
  'gps': ['Use my location', 'استفاده از موقعیت من'], 'saved': ['Saved cities', 'شهرهای ذخیره‌شده'],
};
const WT = [
  ['Clear', 'آسمان صاف'], ['Partly cloudy', 'کمی ابری'], ['Overcast', 'ابری'], ['Fog', 'مه‌آلود'],
  ['Drizzle', 'نم‌نم باران'], ['Rain', 'بارانی'], ['Snow', 'برفی'], ['Thunderstorm', 'رعد و برق'],
];
const FW = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه', 'یکشنبه'];
const JM = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const EW = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const EM = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

List<int> jal(int gy, int gm, int gd) {
  const g = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 355666 + (365 * gy) + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400) + gd + g[gm - 1];
  var jy = -1595 + (33 * (days ~/ 12053));
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) { jy += (days - 1) ~/ 365; days = (days - 1) % 365; }
  final jm = days < 186 ? 1 + days ~/ 31 : 7 + (days - 186) ~/ 30;
  final jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

(IconData, int) wi(int c, bool day) {
  if (c == 0) return (day ? Icons.wb_sunny_rounded : Icons.nightlight_round, 0);
  if (c == 1 || c == 2) return (day ? Icons.wb_cloudy_rounded : Icons.nights_stay_rounded, 1);
  if (c == 3) return (Icons.cloud_rounded, 2);
  if (c == 45 || c == 48) return (Icons.blur_on_rounded, 3);
  if (c >= 51 && c <= 57) return (Icons.grain_rounded, 4);
  if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return (Icons.water_drop_rounded, 5);
  if ((c >= 71 && c <= 77) || c == 85 || c == 86) return (Icons.ac_unit_rounded, 6);
  return (Icons.thunderstorm_rounded, 7);
}

List<Color> bgc(bool day, int k) {
  final cl = k >= 2;
  if (day) return cl ? [const Color(0xFF566A82), const Color(0xFF8EA0B3)] : [const Color(0xFF2A7DE1), const Color(0xFF7CC4F8)];
  return cl ? [const Color(0xFF151B33), const Color(0xFF39425F)] : [const Color(0xFF070D26), const Color(0xFF1E2B5E)];
}

class City {
  final String name;
  final double lat, lon;
  City(this.name, this.lat, this.lon);
  Map toJson() => {'n': name, 'a': lat, 'o': lon};
  factory City.fromJson(Map j) => City(j['n'], (j['a'] as num).toDouble(), (j['o'] as num).toDouble());
}

class Store extends ChangeNotifier {
  bool fa = true, f = false, loading = true, err = false;
  List<City> cities = [City('Istanbul', 41.0082, 28.9784)];
  int idx = 0, _req = 0;
  Map? d;
  DateTime last = DateTime.fromMillisecondsSinceEpoch(0);
  late SharedPreferences p;
  City get city => cities[idx];
  String get key => '${city.lat},${city.lon}';

  String t(String k) => S[k]![fa ? 1 : 0];
  String dg(String s) => fa ? s.replaceAllMapped(RegExp(r'\d'), (x) => '۰۱۲۳۴۵۶۷۸۹'[int.parse(x[0]!)]) : s;
  String tp(num c) => dg('${(f ? c * 9 / 5 + 32 : c).round()}°');
  String nm(City c) => c.name == '@' ? t('me') : c.name;
  String wd(DateTime d) => fa ? FW[d.weekday - 1] : EW[d.weekday - 1];
  String ds(DateTime d) {
    if (fa) { final j = jal(d.year, d.month, d.day); return dg('${wd(d)} ${j[2]} ${JM[j[1] - 1]}'); }
    return '${wd(d)}, ${EM[d.month - 1]} ${d.day}';
  }

  Future<void> init() async {
    p = await SharedPreferences.getInstance();
    fa = p.getBool('fa') ?? true;
    f = p.getBool('f') ?? false;
    final c = p.getStringList('c');
    if (c != null && c.isNotEmpty) {
      cities = c.map((e) => City.fromJson(jsonDecode(e))).toList();
      idx = math.min(p.getInt('i') ?? 0, cities.length - 1);
    } else {
      final g = await locate();
      if (g != null) { cities = [g]; idx = 0; save(); }
    }
    try {
      final ck = p.getString('cache');
      if (ck != null) { final m = jsonDecode(ck); if (m['k'] == key) d = m['d'] as Map; }
    } catch (_) {}
    notifyListeners();
    await load();
  }

  Future<City?> locate() async {
    try {
      var pm = await Geolocator.checkPermission();
      if (pm == LocationPermission.denied) pm = await Geolocator.requestPermission();
      if (pm == LocationPermission.denied || pm == LocationPermission.deniedForever) return null;
      final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.low, timeLimit: Duration(seconds: 12)));
      return City('@', pos.latitude, pos.longitude);
    } catch (_) { return null; }
  }

  void save() {
    p.setBool('fa', fa);
    p.setBool('f', f);
    p.setInt('i', idx);
    p.setStringList('c', cities.map((e) => jsonEncode(e.toJson())).toList());
  }

  Future<void> load() async {
    final id = ++_req;
    loading = true; err = false; notifyListeners();
    try {
      final u = Uri.parse('https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}'
          '&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m'
          '&hourly=temperature_2m,weather_code,precipitation_probability,is_day'
          '&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,precipitation_probability_max'
          '&timezone=auto&forecast_days=7');
      final r = await http.get(u).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) throw 'http';
      if (id != _req) return;
      d = jsonDecode(r.body) as Map;
      last = DateTime.now();
      p.setString('cache', jsonEncode({'k': key, 'd': d}));
    } catch (_) {
      if (id != _req) return;
      err = true;
    }
    loading = false; notifyListeners();
  }

  void sel(int i) { idx = i; save(); d = null; load(); }
  void add(City c) {
    if (c.name == '@') cities.removeWhere((e) => e.name == '@');
    cities.add(c); idx = cities.length - 1; save(); d = null; load();
  }
  void remove(int i) {
    if (cities.length < 2) return;
    final cur = city;
    cities.removeAt(i);
    final j = cities.indexOf(cur);
    if (j < 0) { idx = 0; save(); d = null; load(); } else { idx = j; save(); notifyListeners(); }
  }
  void toggleLang() { fa = !fa; save(); notifyListeners(); }
  void toggleUnit() { f = !f; save(); notifyListeners(); }
}

final st = Store();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(overlay);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: st,
      builder: (_, __) => MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Skycast',
            theme: ThemeData(brightness: Brightness.dark, useMaterial3: true),
            builder: (c, w) => Directionality(textDirection: st.fa ? TextDirection.rtl : TextDirection.ltr, child: w!),
            home: const Home(),
          ));
}

// Real blur only where it's cheap (header, sheet). Cards use a blur-free glass look.
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets pad;
  final double r;
  final bool dark, blur;
  const Glass({super.key, required this.child, this.pad = const EdgeInsets.all(16), this.r = 26, this.dark = false, this.blur = false});
  @override
  Widget build(BuildContext c) {
    final box = Container(
        padding: pad,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(r),
          gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: dark ? [bk(.5), bk(.34)] : [wh(blur ? .26 : .2), wh(blur ? .1 : .07)]),
          border: Border.all(color: wh(.24), width: 1),
        ),
        child: child);
    if (!blur) return box;
    return ClipRRect(
        borderRadius: BorderRadius.circular(r),
        child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22), child: box));
  }
}

Widget pill(String s, VoidCallback f) => GestureDetector(
    onTap: () { HapticFeedback.selectionClick(); f(); },
    child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
        decoration: BoxDecoration(color: wh(.16), borderRadius: BorderRadius.circular(18), border: Border.all(color: wh(.22))),
        child: Text(s, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13))));

class Reveal extends StatelessWidget {
  final int i;
  final Widget child;
  const Reveal(this.i, this.child, {super.key});
  @override
  Widget build(BuildContext c) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 500 + i * 110),
      curve: Curves.easeOutCubic,
      child: child,
      builder: (_, v, ch) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 20 * (1 - v)), child: ch)));
}

class Sky extends CustomPainter {
  final ValueNotifier<double> t, sc;
  final bool day;
  final int k;
  Sky(this.t, this.sc, this.day, this.k) : super(repaint: Listenable.merge([t, sc]));

  static final stars = () {
    final r = math.Random(7);
    return List.generate(50, (_) => [r.nextDouble(), r.nextDouble() * .65, .5 + r.nextDouble()]);
  }();

  @override
  void paint(Canvas c, Size s) {
    final T = t.value;
    final f0 = math.max(0.0, math.min(1.0, 1 - sc.value / 240));
    final f = f0 * f0; // sun/moon fade out while scrolling
    final soft = .2 + .8 * f; // clouds & stars dim, never vanish
    final dim = k >= 2 ? .3 : 1.0;

    if (!day) {
      for (final q in stars) {
        final a = (.2 + .5 * (.5 + .5 * math.sin(T * 1.1 + q[0] * 40))) * (k >= 2 ? .35 : 1) * soft;
        c.drawCircle(Offset(q[0] * s.width, q[1] * s.height), q[2], Paint()..color = wh(a));
      }
    }
    if (k < 4 && f > .01) {
      final pos = Offset(s.width * .8, s.height * .12 + 4 * math.sin(T * .5));
      final gc = day ? const [255, 236, 160] : const [190, 205, 255];
      c.drawCircle(pos, 64, Paint()..shader = RadialGradient(colors: [
        Color.fromRGBO(gc[0], gc[1], gc[2], .3 * dim * f), Color.fromRGBO(gc[0], gc[1], gc[2], 0)
      ]).createShader(Rect.fromCircle(center: pos, radius: 64)));
      if (day) {
        c.drawCircle(pos, 20, Paint()..color = Color.fromRGBO(255, 245, 210, dim * f));
      } else {
        final full = Path()..addOval(Rect.fromCircle(center: pos, radius: 20));
        final cut = Path()..addOval(Rect.fromCircle(center: pos + const Offset(9, -6), radius: 17));
        c.drawPath(Path.combine(PathOperation.difference, full, cut), Paint()..color = Color.fromRGBO(238, 243, 255, dim * f));
      }
    }
    final n = k >= 2 ? 6 : 3;
    final o = (day ? (k >= 2 ? .45 : .26) : (k >= 2 ? .2 : .09)) * soft;
    final cp = Paint()..color = wh(o);
    for (var i = 0; i < n; i++) {
      final w = 150.0 + (i * 53) % 90;
      final x = (T * (5 + i * 2.5) + i * 190) % (s.width + 2 * w) - w;
      final y = s.height * (.09 + .1 * i) + 6 * math.sin(T * .3 + i);
      c.drawPath(
          Path()
            ..addRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, y), width: w, height: w * .26), Radius.circular(w * .13)))
            ..addOval(Rect.fromCircle(center: Offset(x - w * .12, y - w * .1), radius: w * .15))
            ..addOval(Rect.fromCircle(center: Offset(x + w * .1, y - w * .14), radius: w * .19)),
          cp);
    }
    if (k == 4 || k == 5 || k == 7) {
      final p = Paint()..color = wh(.3)..strokeWidth = 1.3;
      for (var i = 0; i < 55; i++) {
        final x = (i * 53.0) % s.width, y = (T * 520 + i * 97.0) % s.height;
        c.drawLine(Offset(x, y), Offset(x - 3, y + 13), p);
      }
    }
    if (k == 6) {
      final p = Paint()..color = wh(.75);
      for (var i = 0; i < 50; i++) {
        final x = ((i * 53.0) + 20 * math.sin(T + i)) % s.width, y = (T * 60 + i * 97.0) % s.height;
        c.drawCircle(Offset(x, y), 2, p);
      }
    }
  }

  @override
  bool shouldRepaint(Sky o) => o.day != day || o.k != k;
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  final time = ValueNotifier<double>(0), off = ValueNotifier<double>(0);
  final sc = ScrollController();
  late final Ticker tk;
  Duration lastTick = Duration.zero;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    sc.addListener(() => off.value = sc.hasClients ? math.max(0.0, sc.offset) : 0.0);
    tk = createTicker((d) {
      if ((d - lastTick).inMilliseconds >= 33) { lastTick = d; time.value = d.inMicroseconds / 1e6; }
    })..start();
    st.init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    tk.dispose();
    sc.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed && !st.loading && DateTime.now().difference(st.last).inMinutes >= 10) st.load();
  }

  Widget bgBox(bool day, int k) {
    final cs = bgc(day, k);
    const dur = Duration(milliseconds: 900);
    return TweenAnimationBuilder<Color?>(
        tween: ColorTween(end: cs[0]), duration: dur,
        builder: (_, a, __) => TweenAnimationBuilder<Color?>(
            tween: ColorTween(end: cs[1]), duration: dur,
            builder: (_, b, __) => ValueListenableBuilder<double>(
                valueListenable: off,
                builder: (_, o, __) {
                  final s = math.min(1.0, o / 260) * .8; // background merges into one tone on scroll
                  final mid = Color.lerp(a, b, .5)!;
                  return DecoratedBox(
                      decoration: BoxDecoration(
                          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color.lerp(a, mid, s)!, Color.lerp(b, mid, s)!])));
                })));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: st,
      builder: (_, __) {
        final d = st.d;
        final day = d == null || d['current']['is_day'] == 1;
        final k = d == null ? 0 : wi(d['current']['weather_code'], day).$2;
        final pad = MediaQuery.of(context).padding;
        if (d == null) WidgetsBinding.instance.addPostFrameCallback((_) { if (off.value != 0) off.value = 0; });
        return AnnotatedRegion<SystemUiOverlayStyle>(
            value: overlay,
            child: Scaffold(
              backgroundColor: Colors.black,
              body: Stack(children: [
                Positioned.fill(child: bgBox(day, k)),
                Positioned.fill(child: RepaintBoundary(child: CustomPaint(painter: Sky(time, off, day, k)))),
                Positioned.fill(child: body(context, d, pad)),
                Positioned(
                    top: 0, left: 0, right: 0, height: pad.top + 64,
                    child: IgnorePointer(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [bk(.2), bk(0)]))))),
                Positioned(
                    bottom: 0, left: 0, right: 0, height: pad.bottom + 28,
                    child: IgnorePointer(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [bk(0), bk(.18)]))))),
                Positioned(left: 16, right: 16, top: pad.top + 8, child: header(context)),
              ]),
            ));
      });

  Widget header(BuildContext c) => Glass(
      r: 24, blur: true,
      pad: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(children: [
        Expanded(
            child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => showModalBottomSheet(
                    context: c, isScrollControlled: true, backgroundColor: Colors.transparent,
                    barrierColor: bk(.3), builder: (_) => const CitySheet()),
                child: Row(children: [
                  const Icon(Icons.location_on_rounded, size: 17),
                  const SizedBox(width: 6),
                  Flexible(child: Text(st.nm(st.city), overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
                  const Icon(Icons.keyboard_arrow_down_rounded, size: 20),
                ]))),
        pill(st.f ? '°F' : '°C', st.toggleUnit),
        const SizedBox(width: 6),
        pill(st.fa ? 'EN' : 'فا', st.toggleLang),
      ]));

  Widget ttl(IconData i, String k) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Row(children: [
        Icon(i, size: 14, color: wh(.65)),
        const SizedBox(width: 6),
        Text(st.t(k), style: TextStyle(fontSize: 12, color: wh(.7), fontWeight: FontWeight.w600, letterSpacing: .3)),
      ]));

  Widget val(String v, [String? u]) => Text.rich(TextSpan(text: v, children: [
        if (u != null) TextSpan(text: ' $u', style: TextStyle(fontSize: 11, color: wh(.65))),
      ]));

  Widget cell(double w, IconData i, String k, Widget v) => SizedBox(
      width: w,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(i, size: 14, color: wh(.65)),
          const SizedBox(width: 5),
          Text(st.t(k), style: TextStyle(fontSize: 12, color: wh(.65))),
        ]),
        const SizedBox(height: 6),
        DefaultTextStyle(style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500, color: Colors.white), child: v),
      ]));

  Widget drow(Map dl, int i, num lo, num hi) {
    final dt = DateTime.parse(dl['time'][i]);
    final double a = ((dl['temperature_2m_min'][i] - lo) / math.max(1, hi - lo)).toDouble();
    final double b = ((dl['temperature_2m_max'][i] - lo) / math.max(1, hi - lo)).toDouble();
    final int pr = (dl['precipitation_probability_max'][i] ?? 0).round();
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
        child: Row(children: [
          SizedBox(width: 64, child: Text(i == 0 ? st.t('today') : st.wd(dt), style: const TextStyle(fontSize: 15))),
          Icon(wi(dl['weather_code'][i], true).$1, size: 21),
          SizedBox(width: 38, child: Text(pr >= 20 ? st.dg('$pr%') : '', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF9EDBFF)))),
          SizedBox(width: 34, child: Text(st.tp(dl['temperature_2m_min'][i]), textAlign: TextAlign.center, style: TextStyle(color: wh(.65)))),
          Expanded(
              child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: LayoutBuilder(builder: (_, bc) {
                    final w = bc.maxWidth;
                    return SizedBox(
                        height: 4,
                        child: Stack(children: [
                          Container(decoration: BoxDecoration(color: wh(.18), borderRadius: BorderRadius.circular(2))),
                          PositionedDirectional(
                              start: w * a, width: math.max(6.0, w * (b - a)), top: 0, bottom: 0,
                              child: Container(decoration: BoxDecoration(
                                  gradient: const LinearGradient(colors: [Color(0xFF7DD3FC), Color(0xFFFCD34D)]),
                                  borderRadius: BorderRadius.circular(2)))),
                        ]));
                  }))),
          SizedBox(width: 34, child: Text(st.tp(dl['temperature_2m_max'][i]), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))),
        ]));
  }

  Widget body(BuildContext c, Map? d, EdgeInsets pad) {
    if (d == null) {
      return Center(
          child: st.loading
              ? const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
              : Padding(
                  padding: const EdgeInsets.all(28),
                  child: Glass(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(st.t('err'), textAlign: TextAlign.center),
                    const SizedBox(height: 14),
                    pill(st.t('retry'), st.load),
                  ]))));
    }
    final cur = d['current'], hr = d['hourly'], dl = d['daily'];
    final info = wi(cur['weather_code'], cur['is_day'] == 1);
    final now = DateTime.parse(cur['time']);
    final ht = hr['time'] as List;
    final cp = (cur['time'] as String).substring(0, 13);
    var s0 = ht.indexWhere((e) => (e as String).compareTo(cp) >= 0);
    if (s0 < 0) s0 = 0;
    final cnt = math.min(24, ht.length - s0);
    final mn = (dl['temperature_2m_min'] as List).cast<num>(), mx = (dl['temperature_2m_max'] as List).cast<num>();
    final lo = mn.reduce((a, b) => math.min(a, b)), hi = mx.reduce((a, b) => math.max(a, b));
    final cw = ((MediaQuery.of(c).size.width - 32 - 36) / 2).floorToDouble() - 1;
    const gap = SizedBox(height: 12);

    return RefreshIndicator(
        onRefresh: st.load,
        edgeOffset: pad.top + 72,
        color: Colors.black87,
        backgroundColor: wh(.92),
        child: ListView(
            controller: sc,
            physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
            padding: EdgeInsets.fromLTRB(16, pad.top + 76, 16, pad.bottom + 28),
            children: [
              Reveal(0, Padding(
                  padding: const EdgeInsets.only(top: 18, bottom: 34),
                  child: Column(children: [
                    if (st.err) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(st.t('off'), style: TextStyle(fontSize: 12, color: wh(.8)))),
                    Text(st.ds(now), style: TextStyle(color: wh(.85), fontSize: 14)),
                    AnimatedSwitcher(
                        duration: const Duration(milliseconds: 280),
                        child: Text(st.tp(cur['temperature_2m']), key: ValueKey(st.tp(cur['temperature_2m'])),
                            style: const TextStyle(fontSize: 100, fontWeight: FontWeight.w200, height: 1.1))),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(info.$1, size: 20),
                      const SizedBox(width: 8),
                      Text(WT[info.$2][st.fa ? 1 : 0], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
                    ]),
                    const SizedBox(height: 6),
                    Text('↑ ${st.tp(mx[0])}   ↓ ${st.tp(mn[0])}', style: TextStyle(fontSize: 15, color: wh(.8))),
                  ]))),
              Reveal(1, Glass(
                  pad: const EdgeInsets.symmetric(vertical: 14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    ttl(Icons.schedule_rounded, 'hr'),
                    const SizedBox(height: 8),
                    SizedBox(
                        height: 104,
                        child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            itemCount: cnt,
                            itemBuilder: (_, i) {
                              final j = s0 + i;
                              final pr = (hr['precipitation_probability'][j] ?? 0).round();
                              return SizedBox(
                                  width: 58,
                                  child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                                    Text(i == 0 ? st.t('now') : st.dg((ht[j] as String).substring(11, 16)), style: TextStyle(fontSize: 12, color: wh(.75))),
                                    Icon(wi(hr['weather_code'][j], hr['is_day'][j] == 1).$1, size: 22),
                                    Text(st.tp(hr['temperature_2m'][j]), style: const TextStyle(fontWeight: FontWeight.w600)),
                                    Text(pr >= 20 ? st.dg('$pr%') : ' ', style: const TextStyle(fontSize: 11, color: Color(0xFF9EDBFF))),
                                  ]));
                            })),
                  ]))),
              gap,
              Reveal(2, Glass(
                  pad: const EdgeInsets.symmetric(vertical: 14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    ttl(Icons.calendar_month_rounded, 'dy'),
                    const SizedBox(height: 4),
                    for (var i = 0; i < (dl['time'] as List).length; i++) drow(dl, i, lo, hi),
                  ]))),
              gap,
              Reveal(3, Glass(
                  pad: const EdgeInsets.all(18),
                  child: Wrap(runSpacing: 20, children: [
                    cell(cw, Icons.thermostat_rounded, 'feels', val(st.tp(cur['apparent_temperature']))),
                    cell(cw, Icons.water_drop_outlined, 'hum', val(st.dg('${cur['relative_humidity_2m'].round()}%'))),
                    cell(cw, Icons.air_rounded, 'wind', Row(mainAxisSize: MainAxisSize.min, children: [
                      val(st.dg('${cur['wind_speed_10m'].round()}'), 'km/h'),
                      const SizedBox(width: 6),
                      Transform.rotate(angle: (cur['wind_direction_10m'] + 180) * math.pi / 180, child: const Icon(Icons.navigation_rounded, size: 16)),
                    ])),
                    cell(cw, Icons.speed_rounded, 'pres', val(st.dg('${cur['pressure_msl'].round()}'), 'hPa')),
                    cell(cw, Icons.wb_sunny_outlined, 'uv', val(st.dg('${(dl['uv_index_max'][0] ?? 0).round()}'))),
                    cell(cw, Icons.umbrella_rounded, 'rain', val(st.dg((dl['precipitation_sum'][0] ?? 0).toStringAsFixed(1)), 'mm')),
                    cell(cw, Icons.wb_twilight_rounded, 'rise', val(st.dg((dl['sunrise'][0] as String).substring(11, 16)))),
                    cell(cw, Icons.nights_stay_outlined, 'set', val(st.dg((dl['sunset'][0] as String).substring(11, 16)))),
                  ]))),
              const SizedBox(height: 22),
              Center(child: Text('Open-Meteo.com', style: TextStyle(fontSize: 11, color: wh(.45)))),
            ]));
  }
}

class CitySheet extends StatefulWidget {
  const CitySheet({super.key});
  @override
  State<CitySheet> createState() => _CS();
}

class _CS extends State<CitySheet> {
  List res = [];
  String q = '';

  Future<void> search(String s) async {
    q = s;
    if (s.trim().length < 2) { setState(() => res = []); return; }
    try {
      final r = await http.get(Uri.parse(
          'https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encodeComponent(s.trim())}&count=8&language=${st.fa ? 'fa' : 'en'}'));
      if (q != s || !mounted) return;
      setState(() => res = (jsonDecode(r.body)['results'] ?? []) as List);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext c) => ListenableBuilder(
      listenable: st,
      builder: (_, __) => Padding(
          padding: EdgeInsets.fromLTRB(12, 0, 12, 12 + MediaQuery.of(c).viewInsets.bottom + MediaQuery.of(c).padding.bottom),
          child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(c).size.height * .72),
              child: Glass(
                  dark: true, blur: true, r: 28,
                  pad: const EdgeInsets.all(14),
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    TextField(
                        onChanged: search,
                        decoration: InputDecoration(
                            hintText: st.t('srch'),
                            prefixIcon: const Icon(Icons.search_rounded),
                            filled: true,
                            fillColor: wh(.1),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
                    const SizedBox(height: 6),
                    ListTile(
                        leading: const Icon(Icons.my_location_rounded),
                        title: Text(st.t('gps')),
                        onTap: () async {
                          final g = await st.locate();
                          if (g != null) { st.add(g); if (mounted) Navigator.pop(context); }
                        }),
                    Flexible(
                        child: ListView(shrinkWrap: true, children: q.trim().length >= 2
                            ? [
                                for (final r in res)
                                  ListTile(
                                      leading: const Icon(Icons.add_location_alt_outlined),
                                      title: Text('${r['name']}'),
                                      subtitle: Text([r['admin1'], r['country']].where((e) => e != null).join('، ')),
                                      onTap: () {
                                        st.add(City(r['name'], (r['latitude'] as num).toDouble(), (r['longitude'] as num).toDouble()));
                                        Navigator.pop(context);
                                      }),
                              ]
                            : [
                                Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 4), child: Text(st.t('saved'), style: TextStyle(fontSize: 12, color: wh(.6)))),
                                for (var i = 0; i < st.cities.length; i++)
                                  ListTile(
                                      leading: Icon(i == st.idx ? Icons.location_on_rounded : Icons.location_on_outlined),
                                      title: Text(st.nm(st.cities[i])),
                                      trailing: st.cities.length > 1 ? IconButton(icon: const Icon(Icons.close_rounded, size: 20), onPressed: () => st.remove(i)) : null,
                                      onTap: () { st.sel(i); Navigator.pop(context); }),
                              ])),
                  ])))));
}
